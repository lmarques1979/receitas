package br.com.marquesapps.receitas.config

class Mail {

	static final String host = "smtp.gmail.com"
	static final int port = 587
	static final String username = "liunit@gmail.com"
	static final String password = "Luizpuc01"
	static final String smtpauth = "true"
	static final String starttlsenable = "true"
	static final String starttlsrequired = "true"
	static final String from = "liunit@gmail.com"
	
}
